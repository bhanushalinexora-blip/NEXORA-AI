package com.bhanushalinexora.personalai

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.app.Activity
import androidx.activity.result.ActivityResultLauncher
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Ink = Color(0xFF080A0F)
private val Panel = Color(0xFF141922)
private val Silver = Color(0xFFD9E1EA)
private val Cyan = Color(0xFF7BDFF2)
private val Muted = Color(0xFF9AA7B6)

data class ChatLine(val fromUser: Boolean, val text: String)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var voiceLauncher: ActivityResultLauncher<Intent>
    private var voiceText by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) voiceText = text
        }
        setContent {
            NexoraApp(
                voiceText = voiceText,
                onVoiceTextConsumed = { voiceText = null },
                onSpeak = { speak(it) },
                onVoice = { launchVoiceInput() },
                onAction = { command -> runSafeCommand(command) }
            )
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val hindi = tts?.setLanguage(Locale("hi", "IN"))
            if (hindi == TextToSpeech.LANG_MISSING_DATA ||
                hindi == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nexora_reply")
    }

    private fun launchVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
            return
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "NEXORA AI ko boliye…")
            }
            voiceLauncher.launch(intent)
        } catch (_: ActivityNotFoundException) {
            speak("Is phone par speech recognition service available nahi hai.")
        }
    }

    private fun runSafeCommand(command: String): String {
        val c = command.lowercase(Locale.ROOT).trim()
        val result = when {
            c.contains("youtube") -> openPackage("com.google.android.youtube", "YouTube")
            c.contains("whatsapp") -> openPackage("com.whatsapp", "WhatsApp")
            c.contains("gmail") || c.contains("email") -> openPackage("com.google.android.gm", "Gmail")
            c.contains("chrome") || c.contains("browser") -> openPackage("com.android.chrome", "Chrome")
            c.contains("time") || c.contains("samay") || c.contains("kitne baje") ->
                "Abhi phone ka time ${java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())} hai."
            c.contains("hello") || c.contains("namaste") || c.contains("नमस्ते") ->
                "Namaste! Main NEXORA AI hoon. Bataiye, main aapki kya madad karun?"
            c.contains("help") || c.contains("madad") || c.contains("kya kar") ->
                "Main abhi YouTube, WhatsApp, Gmail aur Chrome khol sakta hoon, time bata sakta hoon aur notes save kar sakta hoon."
            else -> "Mainne aapki baat samjhi: \"$command\". Is starter version mein AI brain abhi local demo mode mein hai. Internet-based AI baad mein secure backend se jodenge."
        }
        return result
    }

    private fun openPackage(pkg: String, label: String): String {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        return if (launch != null) {
            startActivity(launch)
            "$label khol raha hoon."
        } else {
            "Is phone par $label app nahi mila. Ho sakta hai app installed na ho."
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun NexoraApp(
    voiceText: String?,
    onVoiceTextConsumed: () -> Unit,
    onSpeak: (String) -> Unit,
    onVoice: () -> Unit,
    onAction: (String) -> String
) {
    var input by remember { mutableStateOf("") }
    var lastVoice by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ChatLine(false, "Namaste! Main NEXORA AI hoon. Voice ya chat se command dein."),
            ChatLine(false, "Try karein: “YouTube kholo”, “WhatsApp kholo”, “time batao”.")
        )
    }
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("nexora_memory", 0) }
    var savedNote by remember { mutableStateOf(prefs.getString("note", "") ?: "") }

    LaunchedEffect(voiceText) {
        if (!voiceText.isNullOrBlank()) {
            input = voiceText
            onVoiceTextConsumed()
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan,
            background = Ink,
            surface = Panel,
            onBackground = Silver,
            onSurface = Silver
        )
    ) {
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF111722), Ink, Color(0xFF050609)))
            )
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(48.dp).background(
                            Brush.linearGradient(listOf(Cyan, Silver)), CircleShape
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("N", color = Ink, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("NEXORA AI", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Silver)
                        Text("PERSONAL INTELLIGENCE • DEMO MODE", fontSize = 10.sp, color = Cyan)
                    }
                    Text("●", color = Cyan, fontSize = 16.sp)
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier.size(94.dp).background(
                                Brush.radialGradient(listOf(Cyan.copy(alpha = .7f), Color(0xFF283A50), Panel)),
                                CircleShape
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("N", fontSize = 42.sp, fontWeight = FontWeight.Light, color = Silver)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Ready when you are", color = Silver, fontWeight = FontWeight.SemiBold)
                        Text("Voice • Chat • Safe actions", color = Muted, fontSize = 12.sp)
                        Button(onClick = onVoice, modifier = Modifier.padding(top = 8.dp)) {
                            Text("🎙  Speak to NEXORA")
                        }
                    }
                }

                Text("ASSISTANT CONSOLE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(messages) { line ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start
                        ) {
                            Surface(
                                color = if (line.fromUser) Color(0xFF263747) else Panel,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.widthIn(max = 310.dp)
                            ) {
                                Text(line.text, modifier = Modifier.padding(12.dp), color = Silver)
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Command type karein…", color = Muted) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        if (input.isNotBlank()) {
                            val command = input.trim()
                            messages.add(ChatLine(true, command))
                            val reply = handleLocalCommand(command, prefs) { onAction(it) }
                            messages.add(ChatLine(false, reply))
                            onSpeak(reply)
                            savedNote = prefs.getString("note", "") ?: ""
                            input = ""
                        }
                    }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan,
                        unfocusedBorderColor = Color(0xFF46515F)
                    )
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = onVoice, modifier = Modifier.weight(1f)) { Text("Voice") }
                    Button(
                        onClick = {
                            if (input.isNotBlank()) {
                                val command = input.trim()
                                messages.add(ChatLine(true, command))
                                val reply = handleLocalCommand(command, prefs) { onAction(it) }
                                messages.add(ChatLine(false, reply))
                                onSpeak(reply)
                                savedNote = prefs.getString("note", "") ?: ""
                                input = ""
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Send command") }
                }
                Text(
                    if (savedNote.isBlank()) "Memory: no note saved" else "Memory note: $savedNote",
                    color = Muted, fontSize = 11.sp
                )
            }
        }
    }
}

private fun handleLocalCommand(
    command: String,
    prefs: android.content.SharedPreferences,
    runAction: (String) -> String
): String {
    val c = command.lowercase(Locale.ROOT)
    return when {
        c.startsWith("note ") || c.startsWith("yaad rakho ") || c.startsWith("save note ") -> {
            val note = when {
                c.startsWith("yaad rakho ") -> command.substringAfter("yaad rakho ", "").trim()
                c.startsWith("save note ") -> command.substringAfter("save note ", "").trim()
                else -> command.substringAfter(' ').trim()
            }
            if (note.isBlank()) "Note khali hai. 'note ...' likhein."
            else {
                prefs.edit().putString("note", note).apply()
                "Theek hai, maine ye note is phone par save kar diya: $note"
            }
        }
        c.contains("note dikhao") || c.contains("show note") || c.contains("meri memory") ->
            "Aapka saved note: ${prefs.getString("note", "Abhi koi note save nahi hai.")}"
        else -> runAction(command)
    }
}
